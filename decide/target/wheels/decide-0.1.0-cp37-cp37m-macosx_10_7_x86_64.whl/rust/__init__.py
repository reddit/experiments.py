from .rust import *

__doc__ = rust.__doc__
